// Akademinin önerdiği ders videoları (yalnız akademinin kendi videoları ya da izinli bağlantılar). Biçim: {b: başlık, k: konu, u: bağlantı}
window.VIDEOLAR = [];
